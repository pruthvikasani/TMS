A Pen created at CodePen.io. You can find this one at https://codepen.io/juslwk/pen/xgbDB.

 From CODROPS http://tympanus.net/Tutorials/CircularNavigation/index2.html